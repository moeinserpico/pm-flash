from cmms.models.users import *
from cmms.models.message import *
class Mail:
    @staticmethod
    def SendNewSysMessage(r,title,priority=None):
        print(r)
        print(title)

        if(priority==None):
            priority=5 #lowest val
        sysuser=SysUser.objects.get(id=1)
        touser=SysUser.objects.get(userId__username=r)
        msg="<p>یک سفارش کاری جدید برای {} ایجاد گردید</p><p>خلاصه درخواست:<br/>{}</p>".format(touser.fullName,title)
        sub="سفارش کاری    جدید ایجاد شد"
        Message.objects.create(subject=sub,messageStatus=2,fromUser=sysuser,toUser=touser,Message=msg,msgPririty=priority)

    def SendUpdatedSysMessage(r,title,priority=None):
       if(priority==None):
            priority=5 #lowest val
       sysuser=SysUser.objects.get(userId__username="admin")
       touser=SysUser.objects.get(userId__username=r)
       sub="سفارش کاری بروز گردانی شد"
       msg="<p>سفارش کاری برای کاربر {} بروز گردید.</p><p>خلاصه درخواست:<br/>{}</p>".format(touser.fullName,title)
       Message.objects.create(subject=sub,messageStatus=2,fromUser=sysuser,toUser=touser,Message=msg,msgPririty=priority)
