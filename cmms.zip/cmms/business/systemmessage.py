from __future__ import unicode_literals
from enum import Enum
class WOPartMsg(Enum):
    Success='دخیره با موفقیت'
    NotEnouphPart='عدم موجودی کافی قطعه'
    Pass='هیچی'
